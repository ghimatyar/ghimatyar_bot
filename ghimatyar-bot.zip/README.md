
# Ghimatyar Bot

This Telegram bot posts updated prices of gold, coins, currencies, and cryptocurrencies to a channel every 15 minutes as an image.

## Environment Variables

- BOT_TOKEN: Your Telegram bot token
- CHANNEL_ID: Your Telegram channel ID (e.g., @yourchannel)

## Running Locally

```bash
pip install -r requirements.txt
python main.py
```

## Deployment

You can deploy this bot on Render, Railway, or any other cloud service. Just set the environment variables and run the bot.
