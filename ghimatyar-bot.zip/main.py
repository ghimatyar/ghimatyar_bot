
import os
import time
import requests
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from telegram import Bot
from telegram.error import TelegramError

BOT_TOKEN = os.getenv('BOT_TOKEN')
CHANNEL_ID = os.getenv('CHANNEL_ID')

bot = Bot(token=BOT_TOKEN)

def fetch_prices():
    # Dummy data fetch function, replace with real API calls
    # For example:
    gold_18k = "1,200,000 IRR"
    gold_24k = "1,600,000 IRR"
    coin_full = "13,000,000 IRR"
    coin_half = "6,500,000 IRR"
    coin_quarter = "3,500,000 IRR"
    dollar_price = "42,000 IRR"
    bitcoin_price = "30,000 USD"
    ethereum_price = "1,800 USD"
    ripple_price = "0.45 USD"

    return {
        "Gold 18k": gold_18k,
        "Gold 24k": gold_24k,
        "Coin Full": coin_full,
        "Coin Half": coin_half,
        "Coin Quarter": coin_quarter,
        "Dollar": dollar_price,
        "Bitcoin": bitcoin_price,
        "Ethereum": ethereum_price,
        "Ripple": ripple_price,
    }

def create_image(prices, channel_id):
    width, height = 800, 600
    image = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(image)

    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    try:
        font = ImageFont.truetype(font_path, 24)
    except IOError:
        font = ImageFont.load_default()

    y_text = 20
    draw.text((20, y_text), "قیمت روزانه طلا و ارز", fill="black", font=font)
    y_text += 40

    for item, price in prices.items():
        draw.text((20, y_text), f"{item}: {price}", fill="black", font=font)
        y_text += 30

    # Add channel id at bottom
    draw.text((20, height - 40), f"کانال: {channel_id}", fill="gray", font=font)

    bio = BytesIO()
    image.save(bio, format="PNG")
    bio.seek(0)
    return bio

def send_update():
    prices = fetch_prices()
    image = create_image(prices, CHANNEL_ID)

    try:
        bot.send_photo(chat_id=CHANNEL_ID, photo=image, caption="آخرین قیمت‌ها")
        print("Update sent successfully")
    except TelegramError as e:
        print(f"Failed to send update: {e}")

def main():
    while True:
        send_update()
        time.sleep(900)  # 900 seconds = 15 minutes

if __name__ == "__main__":
    main()
